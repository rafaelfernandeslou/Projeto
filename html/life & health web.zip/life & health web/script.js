/* ====================================================
   Life & Health Web – Script de Controle das Abas e Interações
   ==================================================== */

'use strict';

// ============================================================
// 1. SISTEMA DE NAVEGAÇÃO ENTRE ABAS
// ============================================================
function switchTab(tabId) {
  // Ocultar todas as seções de abas
  const tabContents = document.querySelectorAll('.tab-content');
  tabContents.forEach(tab => tab.classList.remove('active'));

  // Desativar botões da barra de navegação
  const navBtns = document.querySelectorAll('.nav__tab-btn');
  navBtns.forEach(btn => {
    if (btn.getAttribute('data-tab') === tabId) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });

  function switchTab(TabId) {
    const navBtns = document.querySelectorAll('')
  }

  // Ativar a aba solicitada
  const targetTab = document.getElementById(`tab-${tabId}`);
  if (targetTab) {
    targetTab.classList.add('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // Fechar menu mobile se estiver aberto
  const navLinks = document.getElementById('navLinks');
  const navBurger = document.getElementById('navBurger');
  if (navLinks && navLinks.classList.contains('open')) {
    navLinks.classList.remove('open');
    if (navBurger) navBurger.classList.remove('open');
  }

  // Se abrir a aba de Meus Agendamentos, atualizar lista
  if (tabId === 'meus-agendamentos') {
    renderizarAgendamentos();
  }
}

// Configurar clique dos botões de abas no Header
document.addEventListener('DOMContentLoaded', () => {
  const navTabBtns = document.querySelectorAll('.nav__tab-btn');
  navTabBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const tabId = btn.getAttribute('data-tab');
      if (tabId) {
        switchTab(tabId);
      }
    });
  });

  // Mobile Menu Toggle
  const navBurger = document.getElementById('navBurger');
  const navLinks = document.getElementById('navLinks');
  if (navBurger && navLinks) {
    navBurger.addEventListener('click', () => {
      navLinks.classList.toggle('open');
      navBurger.classList.toggle('open');
    });
  }

  // Inicializar agendamentos e carrinho
  inicializarAgendamentosPadrao();
  renderizarAgendamentos();
  renderizarCarrinho();

  // Data mínima para agendamento (Amanhã)
  const inputData = document.getElementById('agendaData');
  if (inputData) {
    const amanha = new Date();
    amanha.setDate(amanha.getDate() + 1);
    inputData.min = amanha.toISOString().split('T')[0];
  }
});


// ============================================================
// 2. ABA: AGENDAMENTO DE CONSULTAS
// ============================================================
const formAgendamento = document.getElementById('formAgendamento');
if (formAgendamento) {
  formAgendamento.addEventListener('submit', (e) => {
    e.preventDefault();

    const nome = document.getElementById('agendaNome').value.trim();
    const telefone = document.getElementById('agendaTelefone').value.trim();
    const email = document.getElementById('agendaEmail').value.trim();
    const especialidade = document.getElementById('agendaEspecialidade').value;
    const medico = document.getElementById('agendaMedico').value;
    const modalidade = document.getElementById('agendaModalidade').value;
    const data = document.getElementById('agendaData').value;
    const horario = document.getElementById('agendaHorario').value;
    const obs = document.getElementById('agendaObs').value.trim();

    if (!nome || !telefone || !email || !especialidade || !medico || !data || !horario) {
      alert('Por favor, preencha todos os campos obrigatórios (*)');
      return;
    }

    // Criar objeto do agendamento
    const novoAgendamento = {
      id: Date.now(),
      nome,
      telefone,
      email,
      especialidade,
      medico,
      modalidade,
      data,
      horario,
      obs,
      status: 'Confirmado'
    };

    // Salvar no localStorage
    salvarNovoAgendamento(novoAgendamento);

    alert(`✅ Consulta agendada com sucesso para ${data} às ${horario} com ${medico}!`);
    formAgendamento.reset();

    // Redirecionar para a aba de Meus Agendamentos
    switchTab('meus-agendamentos');
  });
}

function filtrarMedicosPorEspecialidade(especialidade) {
  const selectMedico = document.getElementById('agendaMedico');
  if (!selectMedico) return;

  const medicosMap = {
    'Clínica Geral': 'Dr. Carlos Silva - Clínica Geral',
    'Cardiologia': 'Dra. Juliana Mendes - Cardiologia',
    'Fisioterapia': 'Dr. Rafael Torres - Fisioterapia',
    'Nutrição': 'Dra. Beatriz Santos - Nutrição',
    'Psicologia': 'Dr. Lucas Oliveira - Psicologia',
    'Ortopedia': 'Dra. Fernanda Rocha - Ortopedia'
  };

  if (especialidade && medicosMap[especialidade]) {
    for (let i = 0; i < selectMedico.options.length; i++) {
      if (selectMedico.options[i].text.includes(especialidade)) {
        selectMedico.selectedIndex = i;
        break;
      }
    }
  }
}


// ============================================================
// 3. ABA: CONSULTAR MEUS AGENDAMENTOS
// ============================================================
function inicializarAgendamentosPadrao() {
  const agendamentosExistentes = localStorage.getItem('lifeHealth_agendamentos');
  if (!agendamentosExistentes) {
    const dadosPadrao = [
      {
        id: 1,
        nome: 'Paciente Modelo',
        medico: 'Dr. Carlos Silva (Clínica Geral)',
        especialidade: 'Clínica Geral',
        modalidade: 'Presencial',
        data: '2026-08-25',
        horario: '14:00',
        status: 'Confirmado'
      },
      {
        id: 2,
        nome: 'Paciente Modelo',
        medico: 'Dra. Juliana Mendes (Cardiologia)',
        especialidade: 'Cardiologia',
        modalidade: 'Online',
        data: '2026-09-02',
        horario: '10:00',
        status: 'Pendente'
      }
    ];
    localStorage.setItem('lifeHealth_agendamentos', JSON.stringify(dadosPadrao));
  }
}

function obterAgendamentos() {
  const raw = localStorage.getItem('lifeHealth_agendamentos');
  return raw ? JSON.parse(raw) : [];
}

function salvarNovoAgendamento(agendamento) {
  const lista = obterAgendamentos();
  lista.unshift(agendamento);
  localStorage.setItem('lifeHealth_agendamentos', JSON.stringify(lista));
}

function renderizarAgendamentos(filtroTexto = '') {
  const container = document.getElementById('listaAgendamentosContainer');
  if (!container) return;

  const agendamentos = obterAgendamentos();

  const filtrados = agendamentos.filter(ag => {
    const texto = `${ag.medico} ${ag.especialidade} ${ag.data} ${ag.status}`.toLowerCase();
    return texto.includes(filtroTexto.toLowerCase());
  });

  if (filtrados.length === 0) {
    container.innerHTML = `
      <div class="card-box" style="grid-column: 1 / -1; text-align: center; padding: 40px;">
        <p style="font-size: 1.1rem; color: #64748b;">Nenhum agendamento encontrado.</p>
        <button class="btn btn--primary btn--sm" style="margin-top: 15px;" onclick="switchTab('agendamento')">
          Fazer um Agendamento Agora
        </button>
      </div>
    `;
    return;
  }

  container.innerHTML = filtrados.map(item => `
    <div class="agenda-card">
      <div class="agenda-card__header">
        <span class="badge-status ${item.status === 'Confirmado' ? 'badge-status--confirmado' : 'badge-status--pendente'}">
          ● ${item.status}
        </span>
        <span style="font-size: 0.8rem; color: #64748b;">#ID-${item.id.toString().slice(-4)}</span>
      </div>
      <div>
        <h4>${item.medico}</h4>
        <span class="agenda-spec">${item.especialidade} (${item.modalidade || 'Presencial'})</span>
      </div>
      <div class="agenda-meta">
        <div>📅 <strong>Data:</strong> ${item.data}</div>
        <div>⏰ <strong>Horário:</strong> ${item.horario}</div>
        ${item.obs ? `<div>📝 <em>"${item.obs}"</em></div>` : ''}
      </div>
      <div class="agenda-actions">
        <button class="btn btn--outline btn--sm" style="flex: 1;" onclick="remarcarConsulta(${item.id})">Remarcar</button>
        <button class="btn btn--danger btn--sm" style="flex: 1;" onclick="cancelarConsulta(${item.id})">Cancelar</button>
      </div>
    </div>
  `).join('');
}

function filtrarListaAgendamentos(texto) {
  renderizarAgendamentos(texto);
}

function cancelarConsulta(id) {
  if (confirm('Tem certeza que deseja cancelar esta consulta?')) {
    let agendamentos = obterAgendamentos();
    agendamentos = agendamentos.filter(a => a.id !== id);
    localStorage.setItem('lifeHealth_agendamentos', JSON.stringify(agendamentos));
    renderizarAgendamentos();
    alert('Consulta cancelada.');
  }
}

function remarcarConsulta(id) {
  alert('Redirecionando para a aba de Agendamento para escolher uma nova data.');
  switchTab('agendamento');
}


// ============================================================
// 4. ABA: CONSULTAR MÉDICOS
// ============================================================
function filtrarMedicos(especialidade, btnElement) {
  // Atualizar classe ativa do botão
  const pills = document.querySelectorAll('.filter-pill');
  pills.forEach(p => p.classList.remove('active'));
  if (btnElement) btnElement.classList.add('active');

  const cards = document.querySelectorAll('.doctor-card');
  cards.forEach(card => {
    const spec = card.getAttribute('data-spec');
    if (especialidade === 'todos' || spec === especialidade) {
      card.style.display = 'block';
    } else {
      card.style.display = 'none';
    }
  });
}

function agendarComMedico(nomeMedico, especialidade) {
  switchTab('agendamento');

  const selectEsp = document.getElementById('agendaEspecialidade');
  const selectMed = document.getElementById('agendaMedico');

  if (selectEsp && especialidade) {
    for (let i = 0; i < selectEsp.options.length; i++) {
      if (selectEsp.options[i].value === especialidade) {
        selectEsp.selectedIndex = i;
        break;
      }
    }
  }

  if (selectMed && nomeMedico) {
    for (let i = 0; i < selectMed.options.length; i++) {
      if (selectMed.options[i].value.includes(nomeMedico) || selectMed.options[i].text.includes(nomeMedico)) {
        selectMed.selectedIndex = i;
        break;
      }
    }
  }
}


// ============================================================
// 5. ABA: COMPRAR PRODUTOS (CARRINHO DE COMPRAS)
// ============================================================
let carrinho = [];

function adicionarAoCarrinho(nome, preco) {
  const itemExistente = carrinho.find(item => item.nome === nome);
  if (itemExistente) {
    itemExistente.quantidade += 1;
  } else {
    carrinho.push({ nome, preco, quantidade: 1 });
  }
  renderizarCarrinho();
  alert(`🛒 "${nome}" foi adicionado ao carrinho!`);
}

function removerDoCarrinho(index) {
  carrinho.splice(index, 1);
  renderizarCarrinho();
}

function limparCarrinho() {
  carrinho = [];
  renderizarCarrinho();
}

function renderizarCarrinho() {
  const container = document.getElementById('carrinhoItens');
  const totalEl = document.getElementById('carrinhoTotal');
  const btnFinalizar = document.getElementById('btnFinalizarCompra');

  if (!container || !totalEl) return;

  if (carrinho.length === 0) {
    container.innerHTML = '<p class="empty-cart-msg">Seu carrinho está vazio.</p>';
    totalEl.textContent = 'R$ 0,00';
    if (btnFinalizar) btnFinalizar.disabled = true;
    return;
  }

  let total = 0;
  container.innerHTML = carrinho.map((item, index) => {
    const subtotal = item.preco * item.quantidade;
    total += subtotal;
    return `
      <div class="cart-item-row">
        <div>
          <strong>${item.nome}</strong> (${item.quantidade}x)
          <div style="font-size: 0.8rem; color: #64748b;">R$ ${item.preco.toFixed(2)} cada</div>
        </div>
        <div style="display: flex; align-items: center;">
          <span style="font-weight: 700;">R$ ${subtotal.toFixed(2)}</span>
          <span class="cart-item-remove" onclick="removerDoCarrinho(${index})" title="Remover">&times;</span>
        </div>
      </div>
    `;
  }).join('');

  totalEl.textContent = `R$ ${total.toFixed(2).replace('.', ',')}`;
  if (btnFinalizar) btnFinalizar.disabled = false;
}

function finalizarCompra() {
  if (carrinho.length === 0) return;
  alert('🎉 Pedido realizado com sucesso! Obrigado por comprar na Life & Health.');
  limparCarrinho();
}


// ============================================================
// 6. ABA: LOGIN & CADASTRO
// ============================================================
function realizarLogin(event) {
  event.preventDefault();
  const email = document.getElementById('loginEmail').value;
  alert(`✅ Bem-vindo de volta! Login efetuado com sucesso para: ${email}`);
  switchTab('meus-agendamentos');
}

function realizarCadastro(event) {
  event.preventDefault();
  const nome = document.getElementById('cadNome').value.trim();
  const email = document.getElementById('cadEmail').value.trim();
  const senha = document.getElementById('cadSenha').value;
  const senhaConf = document.getElementById('cadSenhaConf').value;

  if (senha !== senhaConf) {
    alert('⚠️ As senhas digitadas não conferem. Por favor, verifique.');
    return;
  }

  alert(`🎉 Parabéns, ${nome}! Sua conta foi criada com sucesso.`);
  switchTab('login');
}

